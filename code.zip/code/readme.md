
# TDT4173 Machine Learning Exercise 1 #
In order to make sure you have all the packages required to run my code cd into hte root directory and run following command:

```python
pip install -r requirements.txt
```

The files and their connection to the exercises is shon below:

## Task 1 ##
Task1.py

## Task 2 ##
Task2.py (Defining the core methods)
DataSet1.py
DataSet2.py
DataSet2Transformed.py


All the files should be runnable, in this order to follow the exercise.
